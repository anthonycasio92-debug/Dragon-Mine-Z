// kubejs/server_scripts/disable_capsule_items.js

const CapsuleItemClass = Java.loadClass('capsule.items.CapsuleItem');

let capsulePurgeTicks = 0;

ServerEvents.recipes(function (event) {
    // Blueprint recipes
    event.remove({ id: 'capsule:blueprint' });
    event.remove({ type: 'capsule:blueprint_capsule' });

    event.remove({ id: 'capsule:blueprint_change' });
    event.remove({ type: 'capsule:blueprint_change' });

    event.remove({ id: 'capsule:aggregate_all_prefabs' });
    event.remove({ type: 'capsule:aggregate_all_prefabs' });

    // Overpowered Capsule recipe
    event.remove({ id: 'capsule:capsule_op' });

    console.log(
        '[DBZ Legacy Reborn] Capsule blueprints and overpowered capsule recipes disabled.'
    );
});

PlayerEvents.tick(function (event) {
    const player = event.player;

    if (player.age % 20 !== 0) {
        return;
    }

    const inventory = player.getInventory();

    for (let slot = 0; slot < inventory.getContainerSize(); slot++) {
        const stack = inventory.getItem(slot);

        if (stack.isEmpty() || stack.id !== 'capsule:capsule') {
            continue;
        }

        const tag = stack.nbt;

        const isBlueprint =
            CapsuleItemClass.isBlueprint(stack);

        const isOverpowered =
            tag != null &&
            (
                tag.getBoolean('overpowered') ||
                tag.getInt('overpowered') === 1
            );

        if (isBlueprint || isOverpowered) {
            inventory.setItem(slot, Item.empty);
        }
    }

    const enderChest = player.getEnderChestInventory();

    for (let slot = 0; slot < enderChest.getContainerSize(); slot++) {
        const stack = enderChest.getItem(slot);

        if (stack.isEmpty() || stack.id !== 'capsule:capsule') {
            continue;
        }

        const tag = stack.nbt;

        const isBlueprint =
            CapsuleItemClass.isBlueprint(stack);

        const isOverpowered =
            tag != null &&
            (
                tag.getBoolean('overpowered') ||
                tag.getInt('overpowered') === 1
            );

        if (isBlueprint || isOverpowered) {
            enderChest.setItem(slot, Item.empty);
        }
    }
});

ServerEvents.tick(function (event) {
    capsulePurgeTicks++;

    if (capsulePurgeTicks < 100) {
        return;
    }

    capsulePurgeTicks = 0;

    event.server.runCommandSilent(
        'minecraft:kill @e[type=minecraft:item,nbt={Item:{id:"capsule:capsule",tag:{sourceInventory:{}}}}]'
    );

    event.server.runCommandSilent(
        'minecraft:kill @e[type=minecraft:item,nbt={Item:{id:"capsule:capsule",tag:{overpowered:1}}}]'
    );
});

ServerEvents.loaded(function () {
    console.log(
        '[DBZ Legacy Reborn] Capsule blueprint and overpowered capsule purge loaded.'
    );
});